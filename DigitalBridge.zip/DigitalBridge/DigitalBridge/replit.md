# Digital Inclusion Portal

## Overview

The Digital Inclusion Portal is a Flask-based web application designed to address India's digital divide by providing comprehensive information and resources about digital connectivity initiatives. The portal serves as a centralized hub for rural communities and underserved populations to access information about broadband access, affordable devices, government digital services, Wi-Fi hotspots, and private sector initiatives aimed at digital inclusion.

The application focuses on bridging the gap between digital services and rural populations through an accessible, mobile-first responsive design that provides practical resources for digital literacy and connectivity.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Template Engine**: Jinja2 templates with a base template pattern for consistent UI
- **CSS Framework**: Bootstrap 5.3.0 for responsive design and component library
- **Icons**: Font Awesome 6.0.0 for consistent iconography
- **JavaScript Libraries**: Leaflet.js for interactive mapping functionality
- **Design Pattern**: Mobile-first responsive design with accessibility considerations
- **Static Assets**: Organized CSS and JavaScript files served through Flask's static file handling

### Backend Architecture
- **Framework**: Flask (Python) with minimal dependencies for simplicity
- **Application Structure**: Single-file Flask application with route-based organization
- **Session Management**: Flask sessions with configurable secret key
- **Error Handling**: Try-catch blocks for file operations with graceful fallbacks
- **Logging**: Python logging module configured at DEBUG level for development

### Data Storage Solutions
- **Primary Storage**: JSON files for static data (no database required)
- **Data Organization**: Structured JSON files in `/data` directory for different content types
- **Content Types**: Devices catalog, partner information, Wi-Fi hotspots data
- **File Structure**: Separate JSON files for modularity and easy maintenance

### Navigation and Routing
- **Route Structure**: Simple Flask routes corresponding to main portal sections
- **Content Sections**: Home, Rural Broadband, Affordable Devices, Digital Governance, Wi-Fi Locator, Private Initiatives
- **Template Inheritance**: Base template with block-based content extension
- **Error Recovery**: Fallback data structures when JSON files are unavailable

### UI/UX Design Principles
- **Accessibility**: Large fonts, high contrast colors, screen reader friendly
- **Mobile-First**: Responsive design optimized for mobile devices
- **Progressive Enhancement**: Core functionality works without JavaScript
- **Visual Hierarchy**: Color-coded sections with distinct themes for different portal areas

## External Dependencies

### Frontend Dependencies (CDN-based)
- **Bootstrap 5.3.0**: UI framework and responsive grid system
- **Font Awesome 6.0.0**: Icon library for consistent visual elements
- **Leaflet.js 1.9.4**: Interactive mapping library for Wi-Fi hotspot visualization
- **OpenStreetMap**: Tile provider for map data

### Python Dependencies
- **Flask**: Web framework for routing and template rendering
- **Jinja2**: Template engine (included with Flask)
- **Python Standard Library**: JSON parsing, logging, OS environment variables

### Data Sources
- **Static JSON Files**: Local data storage for device catalogs, partner information, and hotspot locations
- **Government Portal Integration**: Links to official digital governance portals (DigiLocker, MyGov, etc.)
- **Image Assets**: External image hosting via Pixabay CDN for visual content

### Deployment Considerations
- **Environment Variables**: SESSION_SECRET for production security
- **Static File Serving**: Flask development server for static assets
- **Development Mode**: Debug mode enabled for development environment
- **Host Configuration**: Configured for 0.0.0.0 binding on port 5000