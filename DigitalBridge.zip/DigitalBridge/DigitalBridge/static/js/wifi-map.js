// Digital Inclusion Portal - Wi-Fi Map Implementation
// Interactive map using Leaflet.js and OpenStreetMap

let map;
let markersLayer;
let userLocationMarker;
let allHotspots = [];

// Initialize map when page loads
document.addEventListener('DOMContentLoaded', function() {
    initializeMap();
    loadWiFiHotspots();
    setupMapControls();
});

// Initialize Leaflet map
function initializeMap() {
    // Create map centered on India
    map = L.map('wifi-map', {
        center: [20.5937, 78.9629], // Center of India
        zoom: 5,
        zoomControl: true,
        scrollWheelZoom: true
    });

    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors | Digital Inclusion Portal',
        maxZoom: 18,
        minZoom: 3
    }).addTo(map);

    // Create marker layer group
    markersLayer = L.layerGroup().addTo(map);

    // Add map loading indicator
    showMapLoading();
}

// Load Wi-Fi hotspot data from API
async function loadWiFiHotspots() {
    try {
        const response = await fetch('/wifi-data');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        allHotspots = data.hotspots || [];
        
        if (allHotspots.length === 0) {
            showNoDataMessage();
            return;
        }
        
        displayHotspots(allHotspots);
        hideMapLoading();
        
    } catch (error) {
        console.error('Error loading Wi-Fi data:', error);
        showErrorMessage('Failed to load Wi-Fi hotspot data. Please try again later.');
        hideMapLoading();
    }
}

// Display hotspots on map
function displayHotspots(hotspots) {
    // Clear existing markers
    markersLayer.clearLayers();
    
    hotspots.forEach(hotspot => {
        if (!hotspot.latitude || !hotspot.longitude) {
            console.warn('Invalid coordinates for hotspot:', hotspot.name);
            return;
        }
        
        // Create custom icon based on hotspot type
        const icon = createHotspotIcon(hotspot);
        
        // Create marker
        const marker = L.marker([hotspot.latitude, hotspot.longitude], {
            icon: icon,
            title: hotspot.name
        });
        
        // Create popup content
        const popupContent = createPopupContent(hotspot);
        marker.bindPopup(popupContent, {
            maxWidth: 300,
            className: 'wifi-popup'
        });
        
        // Add click event for analytics
        marker.on('click', function() {
            trackHotspotClick(hotspot);
        });
        
        // Add marker to layer group
        markersLayer.addLayer(marker);
    });
    
    // Auto-fit map bounds if there are hotspots
    if (hotspots.length > 0) {
        const group = new L.featureGroup(markersLayer.getLayers());
        map.fitBounds(group.getBounds().pad(0.1));
    }
}

// Create custom icon for hotspot based on type
function createHotspotIcon(hotspot) {
    let iconColor, iconClass;
    
    switch (hotspot.type) {
        case 'free':
            iconColor = '#28a745'; // Green for free
            iconClass = 'fa-wifi';
            break;
        case 'paid':
            iconColor = '#ffc107'; // Yellow for paid
            iconClass = 'fa-wifi';
            break;
        case 'community':
            iconColor = '#007bff'; // Blue for community centers
            iconClass = 'fa-building';
            break;
        default:
            iconColor = '#6c757d'; // Gray for unknown
            iconClass = 'fa-wifi';
    }
    
    return L.divIcon({
        html: `<i class="fas ${iconClass}" style="color: ${iconColor}; font-size: 20px; text-shadow: 1px 1px 2px rgba(0,0,0,0.5);"></i>`,
        iconSize: [30, 30],
        iconAnchor: [15, 15],
        popupAnchor: [0, -15],
        className: 'wifi-marker'
    });
}

// Create popup content for hotspot
function createPopupContent(hotspot) {
    const typeLabels = {
        'free': '<span class="badge bg-success">Free Wi-Fi</span>',
        'paid': '<span class="badge bg-warning text-dark">Paid Wi-Fi</span>',
        'community': '<span class="badge bg-primary">Community Center</span>'
    };
    
    let content = `
        <div class="wifi-popup-content">
            <h6 class="mb-2">${escapeHtml(hotspot.name)}</h6>
            <div class="mb-2">${typeLabels[hotspot.type] || '<span class="badge bg-secondary">Unknown</span>'}</div>
    `;
    
    if (hotspot.address) {
        content += `<p class="small mb-2"><i class="fas fa-map-marker-alt me-1"></i>${escapeHtml(hotspot.address)}</p>`;
    }
    
    if (hotspot.provider) {
        content += `<p class="small mb-2"><i class="fas fa-building me-1"></i>Provider: ${escapeHtml(hotspot.provider)}</p>`;
    }
    
    if (hotspot.speed) {
        content += `<p class="small mb-2"><i class="fas fa-tachometer-alt me-1"></i>Speed: ${escapeHtml(hotspot.speed)}</p>`;
    }
    
    if (hotspot.hours) {
        content += `<p class="small mb-2"><i class="fas fa-clock me-1"></i>Hours: ${escapeHtml(hotspot.hours)}</p>`;
    }
    
    if (hotspot.contact) {
        content += `<p class="small mb-2"><i class="fas fa-phone me-1"></i>${escapeHtml(hotspot.contact)}</p>`;
    }
    
    if (hotspot.notes) {
        content += `<p class="small text-muted mb-0">${escapeHtml(hotspot.notes)}</p>`;
    }
    
    content += `
            <div class="mt-2">
                <button class="btn btn-sm btn-outline-primary" onclick="getDirections(${hotspot.latitude}, ${hotspot.longitude})">
                    <i class="fas fa-directions me-1"></i>Get Directions
                </button>
            </div>
        </div>
    `;
    
    return content;
}

// Setup map control buttons
function setupMapControls() {
    // Locate me button
    document.getElementById('locate-me').addEventListener('click', locateUser);
    
    // Show all hotspots button
    document.getElementById('show-all').addEventListener('click', showAllHotspots);
    
    // Filter free Wi-Fi button
    document.getElementById('filter-free').addEventListener('click', filterFreeWiFi);
}

// Locate user's current position
function locateUser() {
    if (!navigator.geolocation) {
        alert('Geolocation is not supported by this browser.');
        return;
    }
    
    const locateBtn = document.getElementById('locate-me');
    locateBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Locating...';
    locateBtn.disabled = true;
    
    navigator.geolocation.getCurrentPosition(
        function(position) {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            
            // Remove existing user location marker
            if (userLocationMarker) {
                map.removeLayer(userLocationMarker);
            }
            
            // Add user location marker
            userLocationMarker = L.marker([lat, lng], {
                icon: L.divIcon({
                    html: '<i class="fas fa-user" style="color: #dc3545; font-size: 20px; text-shadow: 1px 1px 2px rgba(0,0,0,0.5);"></i>',
                    iconSize: [30, 30],
                    iconAnchor: [15, 15],
                    className: 'user-location-marker'
                })
            }).addTo(map);
            
            userLocationMarker.bindPopup('<strong>Your Location</strong>').openPopup();
            
            // Center map on user location
            map.setView([lat, lng], 12);
            
            // Find nearest hotspots
            findNearestHotspots(lat, lng);
            
            // Reset button
            locateBtn.innerHTML = '<i class="fas fa-location-arrow me-1"></i>Find My Location';
            locateBtn.disabled = false;
        },
        function(error) {
            console.error('Geolocation error:', error);
            let message = 'Unable to retrieve your location.';
            
            switch (error.code) {
                case error.PERMISSION_DENIED:
                    message = 'Location access denied. Please enable location services.';
                    break;
                case error.POSITION_UNAVAILABLE:
                    message = 'Location information unavailable.';
                    break;
                case error.TIMEOUT:
                    message = 'Location request timed out.';
                    break;
            }
            
            alert(message);
            
            // Reset button
            locateBtn.innerHTML = '<i class="fas fa-location-arrow me-1"></i>Find My Location';
            locateBtn.disabled = false;
        },
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 300000 // 5 minutes
        }
    );
}

// Show all hotspots
function showAllHotspots() {
    displayHotspots(allHotspots);
    
    // Update filter button states
    document.getElementById('show-all').classList.add('active');
    document.getElementById('filter-free').classList.remove('active');
    
    // Auto-fit bounds
    if (allHotspots.length > 0) {
        const group = new L.featureGroup(markersLayer.getLayers());
        map.fitBounds(group.getBounds().pad(0.1));
    }
}

// Filter only free Wi-Fi hotspots
function filterFreeWiFi() {
    const freeHotspots = allHotspots.filter(hotspot => hotspot.type === 'free');
    displayHotspots(freeHotspots);
    
    // Update filter button states
    document.getElementById('filter-free').classList.add('active');
    document.getElementById('show-all').classList.remove('active');
    
    if (freeHotspots.length === 0) {
        alert('No free Wi-Fi hotspots found in the current data.');
        return;
    }
    
    // Auto-fit bounds
    const group = new L.featureGroup(markersLayer.getLayers());
    map.fitBounds(group.getBounds().pad(0.1));
}

// Find nearest hotspots to user location
function findNearestHotspots(userLat, userLng) {
    // Calculate distances and sort
    const hotspotsWithDistance = allHotspots.map(hotspot => {
        const distance = calculateDistance(userLat, userLng, hotspot.latitude, hotspot.longitude);
        return { ...hotspot, distance };
    }).sort((a, b) => a.distance - b.distance);
    
    // Get top 5 nearest hotspots
    const nearestHotspots = hotspotsWithDistance.slice(0, 5);
    
    // Display notification about nearest hotspots
    if (nearestHotspots.length > 0) {
        const nearest = nearestHotspots[0];
        const message = `Nearest Wi-Fi hotspot: ${nearest.name} (${nearest.distance.toFixed(2)} km away)`;
        
        // Show notification
        showNotification(message, 'info');
    }
}

// Calculate distance between two coordinates (Haversine formula)
function calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Radius of the Earth in kilometers
    const dLat = deg2rad(lat2 - lat1);
    const dLon = deg2rad(lon2 - lon1);
    const a = 
        Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
        Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const d = R * c; // Distance in kilometers
    return d;
}

function deg2rad(deg) {
    return deg * (Math.PI/180);
}

// Get directions to a hotspot
function getDirections(lat, lng) {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
    window.open(url, '_blank');
}

// Utility functions
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showMapLoading() {
    const mapContainer = document.getElementById('wifi-map');
    mapContainer.classList.add('loading');
}

function hideMapLoading() {
    const mapContainer = document.getElementById('wifi-map');
    mapContainer.classList.remove('loading');
}

function showNoDataMessage() {
    const mapContainer = document.getElementById('wifi-map');
    mapContainer.innerHTML = `
        <div class="d-flex align-items-center justify-content-center h-100 text-muted">
            <div class="text-center">
                <i class="fas fa-wifi fa-3x mb-3"></i>
                <h5>No Wi-Fi Data Available</h5>
                <p>Wi-Fi hotspot data is currently unavailable. Please check back later.</p>
            </div>
        </div>
    `;
}

function showErrorMessage(message) {
    const mapContainer = document.getElementById('wifi-map');
    mapContainer.innerHTML = `
        <div class="d-flex align-items-center justify-content-center h-100 text-danger">
            <div class="text-center">
                <i class="fas fa-exclamation-triangle fa-3x mb-3"></i>
                <h5>Error Loading Map</h5>
                <p>${escapeHtml(message)}</p>
                <button class="btn btn-outline-danger" onclick="location.reload()">
                    <i class="fas fa-refresh me-1"></i>Retry
                </button>
            </div>
        </div>
    `;
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 10000; max-width: 300px;';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

function trackHotspotClick(hotspot) {
    // Analytics tracking for hotspot clicks
    console.log('Hotspot clicked:', hotspot.name);
    // In a real implementation, you might send this data to an analytics service
}

// Handle map resize on window resize
window.addEventListener('resize', function() {
    if (map) {
        setTimeout(function() {
            map.invalidateSize();
        }, 100);
    }
});

// Export functions for global access
window.getDirections = getDirections;
